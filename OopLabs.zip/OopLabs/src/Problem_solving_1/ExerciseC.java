package Problem_solving_1;

public class ExerciseC {
}
