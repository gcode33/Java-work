package ProblemSolving11.exercisea;

public class testsoccer {
    public static void main(String[] args){
        Soccer soccer = new Soccer("soccer", 1890, 90, new String[]{"grass", "turf", "blah", "blah", "blah"}, new String[]{"1. dimension", "2. reffere", "ruff"}, 11);
    }
}
