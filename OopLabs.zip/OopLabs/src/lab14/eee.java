package lab14;

public class eee {
}
