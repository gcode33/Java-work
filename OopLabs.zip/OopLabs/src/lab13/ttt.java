package lab13;

public class ttt {
}
