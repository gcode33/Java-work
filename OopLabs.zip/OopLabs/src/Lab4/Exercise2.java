package Lab4;

public class Exercise2 {
    public static void main(String[] args) {
        int sum = 0;
        int hold;
        for (int i = 0; i <= 20; i++) {

            sum = sum+i;


        }
        System.out.printf("the sum of the first 20 positive numbers is %d ",sum);

    }
}
